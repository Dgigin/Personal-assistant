# -*- coding: utf-8 -*-
"""Скрипт создания GitHub Release v1.0.6 и загрузки assets."""

import os
import json
import requests

TOKEN = "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"
REPO = "Dgigin/Personal-assistant"
VERSION = "1.0.6"
HEADERS = {
    "Authorization": f"token {TOKEN}",
    "Accept": "application/vnd.github.v3+json",
}

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def create_release():
    url = f"https://api.github.com/repos/{REPO}/releases"
    payload = {
        "tag_name": f"v{VERSION}",
        "name": f"v{VERSION}",
        "body": "## v1.0.5\n\n"
                "### Исправления\n"
                "- **Очистка stale update.bat**: при запуске `run.bat` теперь удаляет "
                "старый `update.bat`, `apply_update.py` и `update_pending.flag`, "
                "оставшиеся после неудачных обновлений\n"
                "- **Подавление логов Werkzeug**: HTTP-запросы больше не спамят "
                "в консоль (остаются только в файле app.log)\n\n"
                "### Для пользователей с ошибкой «The batch file cannot be found»\n"
                "Если у вас на машине остался старый `update.bat` в "
                "`C:\\Program Files (x86)\\Excel Converter` — удалите его вручную "
                "или дождитесь автообновления до v1.0.5.",
        "draft": False,
        "prerelease": False,
    }
    print(f"[*] Создание релиза v{VERSION}...")
    resp = requests.post(url, headers=HEADERS, json=payload)
    if resp.status_code == 201:
        data = resp.json()
        print(f"[OK] Релиз создан: {data['html_url']}")
        return data
    else:
        print(f"[!] Ошибка создания релиза: {resp.status_code}")
        print(resp.text[:500])
        return None


def upload_asset(release_id, file_path, content_type):
    filename = os.path.basename(file_path)
    url = f"https://uploads.github.com/repos/{REPO}/releases/{release_id}/assets?name={filename}"
    print(f"[*] Загрузка {filename}...")
    with open(file_path, "rb") as f:
        resp = requests.post(url, headers={
            "Authorization": f"token {TOKEN}",
            "Content-Type": content_type,
        }, data=f)
    if resp.status_code == 201:
        print(f"[OK] {filename} загружен")
        return True
    else:
        print(f"[!] Ошибка загрузки {filename}: {resp.status_code}")
        print(resp.text[:300])
        return False


def main():
    test_url = f"https://api.github.com/repos/{REPO}"
    test_resp = requests.get(test_url, headers=HEADERS)
    if test_resp.status_code != 200:
        print(f"[!] Ошибка доступа к репозиторию: {test_resp.status_code}")
        print(test_resp.text[:300])
        return
    print(f"[OK] Доступ к {REPO} подтверждён")

    release = create_release()
    if not release:
        return
    release_id = release["id"]

    # update.zip
    update_path = os.path.join(BASE_DIR, "update.zip")
    if os.path.exists(update_path):
        upload_asset(release_id, update_path, "application/zip")
    else:
        print(f"[!] update.zip не найден: {update_path}")

    # Installer
    installer_path = os.path.join(BASE_DIR, "Output", f"ExcelConverter-Setup-{VERSION}.exe")
    if os.path.exists(installer_path):
        upload_asset(release_id, installer_path, "application/x-msdownload")
    else:
        print(f"[!] Установщик не найден: {installer_path} — компилирую...")
        # Компилируем через ISCC
        iscc = r"C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
        if os.path.exists(iscc):
            os.system(f'"{iscc}" "{os.path.join(BASE_DIR, "installer.iss")}"')
            if os.path.exists(installer_path):
                upload_asset(release_id, installer_path, "application/x-msdownload")
        else:
            print("[!] Inno Setup не найден")

    print(f"\n[OK] Релиз v{VERSION} готов!")
    print(f"    Ссылка: https://github.com/{REPO}/releases/tag/v{VERSION}")


if __name__ == "__main__":
    main()
